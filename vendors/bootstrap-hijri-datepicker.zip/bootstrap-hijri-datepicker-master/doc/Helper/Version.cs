﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BootstrapHijriDate.Helper
{
    public class VersionHelper
    {
        public static string Version => "1.0.0";
    }
}
